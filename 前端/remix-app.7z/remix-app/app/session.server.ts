import { createCookieSessionStorage } from "@remix-run/node";

export type UserSessionData = {
    username: string
}

export const UserSessionStroage = createCookieSessionStorage<UserSessionData>({
    cookie: {
        name: "__session",
        httpOnly: true,
        maxAge: 60,
        path: "/",
        sameSite: "lax",
        secrets: [process.env.SESSION_SECRET as string],
        secure: true
    }
});

export const auth = async (request: Request){
    const session = await UserSessionStroage.getSession(request.headers.get("Cookie"));
    return {username: session.get("username")} as UserSessionData;
}