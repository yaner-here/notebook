import { ActionFunctionArgs, LoaderFunctionArgs, json, redirect } from "@remix-run/node";
import { Form, useFetcher, useLoaderData, useNavigation, useSubmit } from "@remix-run/react";
import { Button, Input, Textarea } from "@nextui-org/react";
import { prisma } from "prisma/prisma.server";
import { auth } from "~/session.server";

export const loader = async (c: LoaderFunctionArgs) => {

    const user = await auth(c.request);
    if(!user.username){
        return redirect("/signin");
    }

    const postId = c.params.postId as string;
    const post = await prisma.post.findUnique({
        where: {
            id: postId
        }
    });

    if(!post){
        throw new Response("Not found", {
            status: 404
        });
    }

    return json({post});
}

export const action = async(c: ActionFunctionArgs) => {
    const postId = c.params.postId as string;
    const formData = await c.request.formData();
    
    const slug = formData.get("slug") as string;
    const title = formData.get("title") as string;
    const content = formData.get("contnet") as string;
    const action = formData.get("action") as "edit" | "delete";

    switch (action) {
        case "edit":
            await prisma.post.update({
                where: {
                    id: postId
                },
                data: {
                    id: slug,
                    title,
                    content
                }
            });
            return redirect(`/posts/${slug}`);
        case "delete":
            await prisma.post.delete({
                where: {
                    id: postId
                }
            });
            return redirect("/");
        default:
            throw new Response("Not found", {
                status: 404
            });
    }
}

export default function Page(){
    const loaderData = useLoaderData<typeof loader>();
    const navigation = useNavigation();
    const deleteFetcher = useFetcher(); 
    const deleteSubmit = useSubmit();
    return (
        <div className="p-12">
            <Form method="post">
                <div className="flex flex-col gap-3">
                    <Input label="slug" name="slug" defaultValue={loaderData.post.id}></Input>
                    <Input label="标题" name="title" defaultValue={loaderData.post.title}></Input>
                    <Textarea label="内容" name="content" defaultValue={loaderData.post.content} minRows={10}></Textarea>
                    <Button name="action" value="edit" type="submit" color="primary" isLoading={navigation.formAction === "/posts/$postId/edit" && navigation.state === "submitting" && navigation.formData?.get("action") === "edit"}>更新</Button>
                    <Button name="action" value="delete" type="submit" color="danger" isLoading={navigation.formAction === "/posts/$postId/edit" && navigation.state === "submitting" && navigation.formData?.get("action") === "delete"}>删除(表单action字段)</Button>
                </div>
            </Form>
            <deleteFetcher.Form style={{width: "100%"}} method="post" action={`/posts/${loaderData.post.id}/delete`}>
                <div className="flex flex-col gap-3 mt-3">
                    <Button type="submit" color="danger" isLoading={deleteFetcher.state === "submitting"}>删除(Form表./delete路由)</Button>
                </div>
            </deleteFetcher.Form>
            <Button name="action" value="delete" color="danger" isLoading={navigation.formAction === "/posts/$postId/edit" && navigation.state === "submitting" && navigation.formData?.get("action") === "delete"} onClick={() => {
                if(confirm("确定删除吗?")){
                    const formData = new FormData();
                    formData.set("action", "delete")
                    deleteSubmit(formData, {
                        method: "post",
                        action: `/posts/${loaderData.post.id}/delete`
                    });
                    
                }
            }}>带确认的删除(表单action字段)</Button>
            <Button name="action" value="delete" color="danger" isLoading={navigation.formAction === "/posts/$postId/edit" && navigation.state === "submitting" && navigation.formData?.get("action") === "delete"} onClick={() => {
                if(confirm("确定删除吗?")){
                    deleteFetcher.submit(null, {
                        method: "post",
                        action: `/posts/${loaderData.post.id}/delete`
                    });
                }
            }}>带确认的删除(表单./delete路由)</Button>
        </div>
    );
}