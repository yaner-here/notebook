import { json, type LoaderFunctionArgs, type MetaFunction } from "@remix-run/node";
import { Link, useLoaderData, useSearchParams } from "@remix-run/react";
import { prisma } from "prisma/prisma.server";
import { Pagination } from "@nextui-org/react";

const PAGE_SIZE = 1;

export const meta: MetaFunction = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export const loader = async (c: LoaderFunctionArgs) => {
  const page = Number(new URL(c.request.url).searchParams.get("page") ?? 1);
  const [posts, total] = await prisma.$transaction([
    prisma.post.findMany({
      orderBy: {
        created_time: "desc"
      },
      take: PAGE_SIZE,
      skip: (page - 1) * PAGE_SIZE
    }),
    prisma.post.count()
  ]);
  return json({posts, pageCount: Math.ceil(total / PAGE_SIZE)});
};

export default function Index() {

  const loaderData = useLoaderData<typeof loader>();
  const [searchParams, setSearchParams] = useSearchParams();
  const page = Number(searchParams.get("page") ?? 1);

  return (
    <div>
      <div className="flex flex-col gap-4 p-12">
        {loaderData.posts.map((post) => {
          return (
            <div key={post.id}>
              <Link to={`/posts/${post.id}`} prefetch="viewport" className="text-xl">{post.title}</Link>
              <div className="text-sm text-gray-400">{post.created_time}</div>
            </div>
          )
        })}
        <Pagination page={page} total={loaderData.pageCount} onChange={(page) => {
          const newSearhParams = new URLSearchParams(searchParams);
          newSearhParams.set("page", String(page))
          setSearchParams(newSearhParams);
        }}></Pagination>
      </div>
    </div>
  );
}
