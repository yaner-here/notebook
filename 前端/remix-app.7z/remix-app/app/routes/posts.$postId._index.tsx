import { LoaderFunctionArgs, json } from "@remix-run/node";
import ReactMarkdown from 'react-markdown';
import { Link, useLoaderData } from "@remix-run/react";
import { prisma } from "prisma/prisma.server";

export const loader = async (c: LoaderFunctionArgs) => {
    const postId = c.params.postId as string;
    const post = await prisma.post.findUnique({
        where: {
            id: postId
        }
    });

    if(!post){
        throw new Response("Not found", {
            status: 404
        });
    }

    return json({post});
}

export default function Page() {
    const loaderData = useLoaderData<typeof loader>();

    return (
        <div className="p-12">
            <div className="mb-3">
                <Link to="edit" className="underline">编辑</Link>
            </div>
            <div className="prose">
                <h1>{loaderData.post.title}</h1>
                <ReactMarkdown>{loaderData.post.content}</ReactMarkdown>
            </div>
        </div>
    )
}