import { Button, Input, Textarea } from "@nextui-org/react"
import { Form, useActionData, useNavigation } from "@remix-run/react"
import { ActionFunctionArgs, json, redirect } from "@remix-run/node"
import { prisma } from "prisma/prisma.server"

export const action = async(c: ActionFunctionArgs) => {
    const formData = await c.request.formData();
    const slug = formData.get("slug") as string;
    const title = formData.get("title") as string;
    const content = formData.get("content") as string;

    let errorResponse = {
        "success": true,
        "errors": {
            "slug": "",
            "title": "",
            "content": ""
        }
    };
    if(!slug){
        errorResponse.success = false;
        errorResponse.errors.slug = "必须填写slug";
    }
    if(!title){
        errorResponse.success = false;
        errorResponse.errors.title = "必须填写title";
    }
    if(!content){
        errorResponse.success = false;
        errorResponse.errors.content = "必须填写content";
    }
    if(!errorResponse.success){
        return json(errorResponse);
    }

    await prisma.post.create({
        data: {
            id: slug,
            title,
            content
        }
    });

    return redirect("/");
}

export default function Page(){

    const navigation = useNavigation();
    const actionData = useActionData<typeof action>();
    const errorResponse = actionData?.errors;

    return (
        <div>
            <Form method="post">
                <div className="flex flex-col gap-3 p-12">
                    <h1 className="text-xl font-black">发布文章</h1>
                    <Input isInvalid={!!errorResponse?.slug} errorMessage={errorResponse?.slug} name="slug" label="slug"></Input>
                    <Input isInvalid={!!errorResponse?.title} errorMessage={errorResponse?.title} name="title" label="文章标题"></Input>
                    <Textarea isInvalid={!!errorResponse?.content} errorMessage={errorResponse?.content} name="content" label="内容"></Textarea>
                    <Button isLoading={navigation.formAction === "/posts/new" && navigation.state === "submitting"} type="submit" color="primary">发布</Button>
                </div>
            </Form>
        </div>
    )
}